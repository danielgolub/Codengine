/*
 * Codengine
 * FilePath: assets/js/backend.js
*/

$(document).ready(function(){
	// CKEDITOR.replace( 'content', {
	// 	// Options...
	// });
});