<h3><?php echo $title; ?></h3>
<p style="font-size: 16px;">
	You're logged in !!!
</p>