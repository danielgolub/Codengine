<h2><?php echo $title; ?></h2>
<p style="font-size: 16px;">
	Please login below:
</p>
<?php echo $notification; ?>
<form action="" method="post">
	<input type="text" class="form-control" name="username" value="admin" placeholder="Username" />
	<input type="password" class="form-control" name="password" value="123" placeholder="Password" style="margin-top: 10px;" />
	<input type="submit" class="btn btn-success pull-right" name="submit" value="Submit" style="margin-top: 10px;" />
</form>