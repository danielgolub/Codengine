
		</div>
		<!-- Scripts -->
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script type="text/javascript" src="http://<?php echo URL; ?>/assets/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="http://<?php echo URL; ?>/assets/ckeditor/ckeditor.js"></script>
		<script type="text/javascript" src="http://<?php echo URL; ?>/assets/js/backend.js"></script>
	</body>
</html>