<?php
/*
 * Codengine
 * FilePath: app/controllers/home.controller.php
*/

class controller_home
{
    public function __construct($params)
    {
        // Setup what we need for this controller
        // $sec = new Security;
        foreach ($params as $key => $val)
        {
            $this->{$key} = $val;
        }
    }

    public function action_index()
    {
    	// this array will be sent to the view as ${$key}
    	$data = array();
    	// check if there are any saved details on the client-end
    	if(isset($_SESSION['username']) && isset($_SESSION['password']))
    	{
    		// if yes, display the welcome page
    		$data['title'] = 'Oh yeah!';
    		View::forge("home/welcome", $data);
    	}

    	else
    	{
    		// if no details are saved, display the error/login page
    		$data['notification'] = '';
    		if(isset($_POST['submit'])) {
    			// $this->sec->_() will securely get the input's value
    			$username = $this->sec->_("username");
    			$password = $this->sec->_("password");
    			// check if something's missing
    			if(empty($username) || empty($password))
    				$data['notification'] = View::error("Please enter all the required details");
    			
    			else
    			{
    				// if everything's fine, than check the credentials
    				$result = $this->action_check($username, $password);
    				if($result === true) {
    					// than credentials are correct
    					$data['notification'] = View::success("You are being transferred");
    				}

    				else
    					$data['notification'] = View::error("Username and/or Password incorrect");
    			}
    		}
    		$data['title'] = 'You are not logged in yet..';
    		View::forge("home/error", $data);
    	}
    }

    public function action_check($username, $password)
    {
    	// make the database query
    	$this->db->make("select", "users");
		$this->db->where(array(
			"username" => $username,
			"password" => $this->sec->password($password),
		));
		// SELECT * FROM USERS WHERE `username` = '".$username."' AND `password` = '".$password."'

		$rows = $this->db->execute("rows");
		if($rows == 1) {
			// than display the success message
			$this->sec->generate_session(array(
				"username" => $username,
				"password" => $password,
			));
			return true;
		}

		else
			return false;
    }
}

?>