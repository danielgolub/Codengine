<?php
/*
 * Codengine
 * FilePath: app/base/Language/Stack/en.stack.php
*/

$_strings_en = array(
	"hi" => "Hello",
	"another" => "test",
);

?>