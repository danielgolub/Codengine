/*
 * Codengine
 * FilePath: assets/js/backend.js
*/

$(document).ready(function(){
	console.log("Codengine is ready to use!");
});
