<?php
/*
 * Codengine
 * FilePath: app/base/Language/Stack/he.stack.php
*/

$_strings_he = array(
	"hi" => "שלום",
	"another" => "בדיקה",
);

?>