
			<!-- Main jumbotron for a primary marketing message or call to action -->
			<div class="jumbotron">
				<h1><?php print_r($strings); ?>, world!</h1>
				<p>Your Codengine app works and ready to use.</p>
				<p><a href="https://github.com/danielgolub/Codengine/wiki/Documentation" class="btn btn-primary btn-lg" role="button" target="_blank">Learn more &raquo;</a></p>
			</div>
