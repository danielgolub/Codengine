<?php echo $error; ?>
<form action="" method="post" enctype="multipart/form-data">
	<input type="file" name="img" class="form-control" style="margin-bottom: 10px;" />
	<input type="submit" class="btn btn-success pull-right" name="submit" value="Submit" />
</form>