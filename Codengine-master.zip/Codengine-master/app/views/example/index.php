You can create views without a template dependency.
<a href="javascript:window.history.back()">Back</a>