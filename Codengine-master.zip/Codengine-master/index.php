<?php
/*
 * Codengine
 * FilePath: index.php
*/

session_start();

REQUIRE_ONCE 'app/start.php';

?>